Integrantes: David Álvarez Sáez y Andrés Teruel Fernández.

Instrucciones de ejecución:

    - Sección áurea:
        - Modificar la función 'theta' y el parámetro 'search_interval' en la función main() de seccion_aurea.py a los valores deseados.
        - Ejecutar el código: python3 seccion_aurea.py

    - Gradiente:
        - Modificar la función 'f', el gradiente de f 'grad_f' y el punto inicial de búsqueda 'x0' en la función main() de gradiente.py a los valores deseados.
        - Ejecutar el código: python3 gradiente.py

    - Davidon-Fletcher-Powell:
        - Modificar la función 'f', el gradiente de f 'grad_f' y el punto inicial de búsqueda 'x0' en la función main() de davidon_fletcher_powell.py a los valores deseados.
        - Ejecutar el código: python3 davidon_fletcher_powell.py

